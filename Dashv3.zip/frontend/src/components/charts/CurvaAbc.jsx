import React from 'react';
import ReactECharts from 'echarts-for-react';

const CurvaABC = ({ data }) => {
  if (!data || !Array.isArray(data) || data.length === 0)
    return <div className="text-white">Sem dados para a curva ABC.</div>;

  const option = {
    tooltip: {
      trigger: 'item',
      backgroundColor: '#1e1e1e',
      borderColor: '#444',
      borderWidth: 1,
      textStyle: { color: '#fff' },
      formatter: (params) => {
        if (params.seriesName === 'Faturamento') {
          const val = params.data.value ?? 0;
          const nome = params.data.name ?? 'Desconhecido';
          const classe = params.data.classe ?? 'C';
          return `
            Produto: ${nome}<br/>
            Faturamento: R$ ${Number(val).toFixed(2)}<br/>
            Classe: ${classe}
          `;
        } else {
          return `% Acumulado: ${Number(params.value).toFixed(2)}%`;
        }
      },
    },
    legend: {
      data: ['Faturamento', '% Acumulado'],
      textStyle: { color: 'white' },
    },
    xAxis: [
      {
        type: 'category',
        data: data.map((e) => e.descricao || 'Desconhecido'),
        axisLabel: { rotate: 45, color: 'white' },
      },
    ],
    yAxis: [
      {
        type: 'value',
        name: 'Faturamento',
        axisLabel: { color: 'white' },
      },
      {
        type: 'value',
        name: '% Acumulado',
        max: 100,
        axisLabel: { color: 'white' },
      },
    ],
    series: [
      {
        name: 'Faturamento',
        type: 'bar',
        data: data.map((e) => ({
          name: e.descricao || 'Sem nome',
          value: Number(e.faturamento ?? 0),
          classe: e.classe_abc ?? 'C',
        })),
        itemStyle: {
          color: (params) => {
            const classe = params.data?.classe;
            if (classe === 'A') return '#00BFFF';
            if (classe === 'B') return '#FFA500';
            if (classe === 'C') return '#DC143C';
            return '#888'; // fallback
          },
        },
      },
      {
        name: '% Acumulado',
        type: 'line',
        yAxisIndex: 1,
        data: data.map((e) => Number(e.percentual_acumulado ?? 0)),
        lineStyle: { color: '#8b5cf6' },
        smooth: true,
      },
    ],
  };

  return (
    <div className="bg-dark rounded-lg p-4 text-white" style={{ width: '100%', height: '400px' }}>
      <h2 className="graph-title mb-4">📊 Curva ABC (Pareto)</h2>
      <ReactECharts option={option} style={{ width: '100%', height: '100%' }} />
    </div>
  );
};

export default CurvaABC;
