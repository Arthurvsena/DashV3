from fastapi import APIRouter, Depends, HTTPException, Header
from sqlalchemy.orm import Session
from database import get_db
from auth import get_password_hash
from utils import get_schema_engine
from pydantic import BaseModel
from typing import Optional, List
from datetime import datetime

router = APIRouter()

class UsuarioBase(BaseModel):
    nome: str
    email: str
    usuario: str

class UsuarioCreate(UsuarioBase):
    senha: str

class UsuarioUpdate(BaseModel):
    nome: Optional[str] = None
    email: Optional[str] = None
    senha: Optional[str] = None

class UsuarioOut(UsuarioBase):
    id: int
    criado_em: datetime

@router.get("/usuarios", response_model=List[UsuarioOut])
def listar_usuarios(x_schema: str = Header(...), db: Session = Depends(get_db)):
    engine = get_schema_engine(x_schema)
    with engine.connect() as conn:
        result = conn.execute("""
            SELECT id, nome, email, criado_em, usuario
            FROM funcionarios
            ORDER BY id ASC
        """)
        return [dict(r) for r in result.fetchall()]

@router.post("/usuarios")
def criar_usuario(usuario: UsuarioCreate, x_schema: str = Header(...), db: Session = Depends(get_db)):
    engine = get_schema_engine(x_schema)
    with engine.connect() as conn:
        existing = conn.execute(
            "SELECT 1 FROM funcionarios WHERE usuario = %s", (usuario.usuario,)
        ).fetchone()
        if existing:
            raise HTTPException(status_code=400, detail="Usuário já existe")

        senha_hash = get_password_hash(usuario.senha)
        conn.execute("""
            INSERT INTO funcionarios (nome, email, usuario, senha_hash, criado_em)
            VALUES (%s, %s, %s, %s, %s)
        """, (usuario.nome, usuario.email, usuario.usuario, senha_hash, datetime.utcnow()))

        return {"msg": "Usuário criado com sucesso"}

@router.put("/usuarios/{id}")
def atualizar_usuario(id: int, dados: UsuarioUpdate, x_schema: str = Header(...), db: Session = Depends(get_db)):
    engine = get_schema_engine(x_schema)
    with engine.connect() as conn:
        updates = []
        values = []

        if dados.nome:
            updates.append("nome = %s")
            values.append(dados.nome)
        if dados.email:
            updates.append("email = %s")
            values.append(dados.email)
        if dados.senha:
            updates.append("senha_hash = %s")
            values.append(get_password_hash(dados.senha))

        if not updates:
            raise HTTPException(status_code=400, detail="Nada para atualizar")

        values.append(id)
        conn.execute(f"""
            UPDATE funcionarios
            SET {', '.join(updates)}
            WHERE id = %s
        """, tuple(values))

        return {"msg": "Usuário atualizado com sucesso"}

@router.delete("/usuarios/{id}")
def deletar_usuario(id: int, x_schema: str = Header(...), db: Session = Depends(get_db)):
    engine = get_schema_engine(x_schema)
    with engine.connect() as conn:
        conn.execute("DELETE FROM funcionarios WHERE id = %s", (id,))
    return {"msg": "Usuário removido com sucesso"}
